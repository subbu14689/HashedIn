package com.chesire.nekome.kitsu

/**
 * Base URL for all Kitsu requests.
 */
const val KITSU_URL = "https://kitsu.io/"
