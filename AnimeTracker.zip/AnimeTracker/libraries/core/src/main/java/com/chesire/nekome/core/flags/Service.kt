package com.chesire.nekome.core.flags

/**
 * All possible supported services.
 */
enum class Service {
    Kitsu,
    Unknown
}
